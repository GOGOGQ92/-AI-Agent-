from pathlib import Path

from src.agents import (
    PolicySearchAgent,
    ProjectReviewAgent,
    RiskIdentifyAgent,
    BiddingStrategyAgent,
    ReviewOrchestrator,
)
from src.llm import LLMClient


def read_text(path: str) -> str:
    return Path(path).read_text(encoding="utf-8")


def main() -> None:
    project_text = read_text("data/project.txt")
    policy_text = read_text("data/policy.txt")

    llm = LLMClient()

    policy_agent = PolicySearchAgent(llm)
    project_agent = ProjectReviewAgent(llm)
    risk_agent = RiskIdentifyAgent(llm)
    bidding_agent = BiddingStrategyAgent(llm)
    orchestrator = ReviewOrchestrator(llm)

    print("\n[1/5] 政策检索 Agent 正在分析政策文件...")
    policy_result = policy_agent.run(policy_text)

    print("\n[2/5] 项目审查 Agent 正在抽取项目关键指标...")
    project_result = project_agent.run(project_text)

    print("\n[3/5] 风险识别 Agent 正在生成六维风险清单...")
    risk_result = risk_agent.run(project_result, policy_result)

    print("\n[4/5] 竞价策略 Agent 正在生成交易策略建议...")
    bidding_result = bidding_agent.run(project_result, policy_result)

    print("\n[5/5] Orchestrator 正在汇总评审报告...")
    final_report = orchestrator.run(
        policy_result=policy_result,
        project_result=project_result,
        risk_result=risk_result,
        bidding_result=bidding_result,
    )

    print("\n================ 抽水蓄能项目前期评审 AI Agent 报告 ================\n")
    print(final_report)


if __name__ == "__main__":
    main()
