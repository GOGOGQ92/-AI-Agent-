from src.llm import LLMClient
from src.prompts import (
    POLICY_AGENT_PROMPT,
    PROJECT_REVIEW_AGENT_PROMPT,
    RISK_IDENTIFY_AGENT_PROMPT,
    BIDDING_STRATEGY_AGENT_PROMPT,
    ORCHESTRATOR_PROMPT,
)


class BaseAgent:
    def __init__(self, llm: LLMClient) -> None:
        self.llm = llm


class PolicySearchAgent(BaseAgent):
    def run(self, policy_text: str) -> str:
        user_prompt = f"""
请提取以下政策文本中与抽水蓄能项目前期评审相关的内容。

政策文本：
{policy_text}
"""
        return self.llm.chat(
            [
                {"role": "system", "content": POLICY_AGENT_PROMPT},
                {"role": "user", "content": user_prompt},
            ]
        )


class ProjectReviewAgent(BaseAgent):
    def run(self, project_text: str) -> str:
        user_prompt = f"""
请从以下项目资料中抽取抽水蓄能项目前期评审的关键指标。

项目资料：
{project_text}
"""
        return self.llm.chat(
            [
                {"role": "system", "content": PROJECT_REVIEW_AGENT_PROMPT},
                {"role": "user", "content": user_prompt},
            ]
        )


class RiskIdentifyAgent(BaseAgent):
    def run(self, project_result: str, policy_result: str) -> str:
        user_prompt = f"""
请根据项目关键指标和政策要点，按照六个维度生成风险清单。

六个维度：
1. 用地
2. 建设
3. 造价
4. 电价
5. 市场交易
6. 合规

项目关键指标：
{project_result}

政策要点：
{policy_result}
"""
        return self.llm.chat(
            [
                {"role": "system", "content": RISK_IDENTIFY_AGENT_PROMPT},
                {"role": "user", "content": user_prompt},
            ]
        )


class BiddingStrategyAgent(BaseAgent):
    def run(self, project_result: str, policy_result: str) -> str:
        user_prompt = f"""
请结合项目关键指标和政策/市场规则，生成抽水蓄能电站日前/实时交易策略及收益测算思路。

项目关键指标：
{project_result}

政策和市场规则：
{policy_result}
"""
        return self.llm.chat(
            [
                {"role": "system", "content": BIDDING_STRATEGY_AGENT_PROMPT},
                {"role": "user", "content": user_prompt},
            ]
        )


class ReviewOrchestrator(BaseAgent):
    def run(
        self,
        policy_result: str,
        project_result: str,
        risk_result: str,
        bidding_result: str,
    ) -> str:
        user_prompt = f"""
请整合以下多个 Agent 的输出，形成一份抽水蓄能项目前期评审报告。

【政策检索 Agent 输出】
{policy_result}

【项目审查 Agent 输出】
{project_result}

【风险识别 Agent 输出】
{risk_result}

【竞价策略 Agent 输出】
{bidding_result}

请按以下格式输出：
1. 项目基本判断
2. 核心风险清单
3. 竞价策略与收益测算思路
4. 需要补充的材料
5. 项目推进建议
6. 后续系统扩展方向
"""
        return self.llm.chat(
            [
                {"role": "system", "content": ORCHESTRATOR_PROMPT},
                {"role": "user", "content": user_prompt},
            ]
        )
