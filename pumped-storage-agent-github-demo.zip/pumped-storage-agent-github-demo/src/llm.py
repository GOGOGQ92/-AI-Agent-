import os
from typing import Dict, List

import requests
from dotenv import load_dotenv


class LLMClient:
    """OpenAI-compatible LLM client.

    后续接入 MiMo API 时，如接口兼容 Chat Completions 格式，
    只需要修改 .env 中的 LLM_BASE_URL、LLM_API_KEY 和 LLM_MODEL。
    """

    def __init__(self) -> None:
        load_dotenv()
        self.use_mock = os.getenv("USE_MOCK_LLM", "true").lower() == "true"
        self.base_url = os.getenv("LLM_BASE_URL", "").rstrip("/")
        self.api_key = os.getenv("LLM_API_KEY", "")
        self.model = os.getenv("LLM_MODEL", "")

    def chat(self, messages: List[Dict[str, str]], temperature: float = 0.2) -> str:
        if self.use_mock:
            return self._mock_response(messages)

        if not self.base_url or not self.api_key or not self.model:
            raise ValueError("请在 .env 中配置 LLM_BASE_URL、LLM_API_KEY、LLM_MODEL。")

        url = f"{self.base_url}/chat/completions"
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
        }
        payload = {
            "model": self.model,
            "messages": messages,
            "temperature": temperature,
        }

        response = requests.post(url, headers=headers, json=payload, timeout=120)
        response.raise_for_status()
        data = response.json()
        return data["choices"][0]["message"]["content"]

    def _mock_response(self, messages: List[Dict[str, str]]) -> str:
        user_content = messages[-1]["content"]

        if "政策" in user_content and "提取" in user_content:
            return (
                "政策要点：\n"
                "1. 抽水蓄能项目需关注电力系统调峰、储能、调频、备用等功能定位。\n"
                "2. 项目应重点核查用地、林地、生态保护红线、水保、环评、移民安置等合规事项。\n"
                "3. 收益机制需关注容量电价、现货价差、辅助服务补偿及地方市场规则。\n"
            )

        if "项目资料" in user_content and "关键指标" in user_content:
            return (
                "项目关键指标：\n"
                "1. 装机容量：1200MW。\n"
                "2. 连续满发小时数：6小时。\n"
                "3. 建设周期：约72个月。\n"
                "4. 接入系统：拟接入500kV电网。\n"
                "5. 敏感问题：施工道路、弃渣场、移民安置、收益测算。\n"
            )

        if "六个维度" in user_content:
            return (
                "六维风险清单：\n"
                "1. 用地风险：施工道路、弃渣场可能涉及林地和生态敏感区。\n"
                "2. 建设风险：地下厂房、输水系统等控制性工程存在工期不确定性。\n"
                "3. 造价风险：征地、移民、环保、水保和地质处理可能推高投资。\n"
                "4. 电价风险：收益对容量电价和现货市场价差高度敏感。\n"
                "5. 市场交易风险：日前/实时价格波动会影响抽发策略收益。\n"
                "6. 合规风险：环评、水保、林地、用地预审和接入系统批复需同步推进。\n"
            )

        if "竞价策略" in user_content or "日前" in user_content:
            return (
                "竞价策略建议：\n"
                "1. 日前市场：低价时段安排抽水，高价时段安排发电，优先锁定峰谷价差。\n"
                "2. 实时市场：根据新能源出力偏差和系统调峰需求动态调整抽发计划。\n"
                "3. 辅助服务：重点关注调频、备用、爬坡等收益机会。\n"
                "4. 约束条件：需考虑库容、启停次数、最小运行时间和抽发转换限制。\n"
                "5. 收益测算：建议建立电价预测 + 运行优化 + 收益风险评估模型。\n"
            )

        return (
            "综合评审结论：\n"
            "该项目具备服务新能源消纳、系统调峰和电力市场交易的综合价值，但前期仍需重点核实"
            "用地生态、弃渣场、移民安置、接入系统和收益机制。建议在补充关键专题论证后谨慎推进，"
            "并同步建设政策库、项目库、电价预测和竞价策略模块，形成企业级抽水蓄能 AI 决策支持系统。"
        )
